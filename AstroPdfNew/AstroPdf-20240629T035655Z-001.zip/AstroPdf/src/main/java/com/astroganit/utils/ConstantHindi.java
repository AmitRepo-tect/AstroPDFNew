package com.astroganit.utils;

public class ConstantHindi {

	public String[] planetNameWithLagna = new String[] { "लग्न", "सूर्य", "चन्द्र", "मंगल", "बुध", "गुरु", "शुक्र",
			"शनि", "राहु", "केतु", "यूरे", "नेप", "प्लूटो" };
	public String[] rasiShortNames = new String[] { "मेष", "वृष", "मिथुन", "कर्क", "सिंह", "कन्या", "तुला", "वृश्चिक",
			"धनु", "मकर", "कुंभ", "मीन" };
	public String[] naksShortNames = new String[] { "अश्विनी", "भरणी", "कृतिका", "रोहिणी", "मृगशिरा", "आद्रा",
			"पुनर्वसु", "पुष्य", "आश्लेषा", "मघा", "पू0फाल्गुनी", "उ0फाल्गुनी", "हस्त", "चित्रा", "स्वाती", "विशाखा",
			"अनुराधा", "ज्येष्ठा", "मूल ", "पूर्वाषा", "उ0षाा", "श्रवण", "धनिष्‍ठा", "शतभिष", "पूर्वाभाद्रपद",
			"उ0भाद्रपद", "रेवती" };
	public String[] birthDetailLabel = new String[] { "uke", "fnaukd", "le;", "LFkku", "v;ka'k" };

}
