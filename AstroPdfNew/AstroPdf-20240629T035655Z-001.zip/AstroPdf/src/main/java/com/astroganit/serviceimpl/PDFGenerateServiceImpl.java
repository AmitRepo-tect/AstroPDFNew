package com.astroganit.serviceimpl;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType0Font;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.springframework.stereotype.Service;

import com.astroganit.calculation.util.Local;
import com.astroganit.kundlilib.dhoro.DesktopHoro;
import com.astroganit.model.PlanetDataModel;
import com.astroganit.service.PDFGenerateService;
import com.astroganit.utils.ConstantHindi;
import com.astroganit.utils.DrawShape;

@Service
public class PDFGenerateServiceImpl implements PDFGenerateService {
	DesktopHoro desktopHoro;
	PDDocument document;
	ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
	PDPageContentStream contentStream;
	ConstantHindi constantHindi;

	public byte[] generatePDF() throws IOException {
		try {
			constantHindi = new ConstantHindi();
			initHoro();
			document = new PDDocument();
			printFirstPage();
			/*
			 * addChart(); addChalitChart();
			 */
			document.save(byteArrayOutputStream);

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return byteArrayOutputStream.toByteArray();
	}

	void addPageHeading(DrawShape drawShape, float pageHeight, float pageWidth) throws Exception {
		drawShape.drawLine(0, pageHeight - 30, pageWidth, pageHeight - 30);
		drawShape.drawText(pageWidth / 2 - 30, pageHeight - 20, "Astro Ganit", 12);
	}

	void printFirstPage() {
		try {
			PDPage page = new PDPage(PDRectangle.A4);
			document.addPage(page);
			contentStream = new PDPageContentStream(document, page);
			contentStream.setLineWidth(1);
			contentStream.setStrokingColor(Color.GRAY);
			contentStream.setNonStrokingColor(Color.BLACK);
			PDRectangle mediaBox = page.getMediaBox();
			float pageWidth = mediaBox.getWidth();
			float pageHeight = mediaBox.getHeight();
			DrawShape drawShape = new DrawShape();
			drawShape.initialize(pageHeight, pageWidth, document, contentStream);
			addPageHeading(drawShape, pageHeight, pageWidth);
			printBirthDetailTable(drawShape, pageHeight, pageWidth);
			contentStream.close();
			// addAvkahadaChakar();
		} catch (Exception e) {

		}
	}

	void printBirthDetailTable(DrawShape drawShape, float pageHeight, float pageWidth) throws IOException {
		drawShape.drawKrutiDevText(20, pageHeight - 50, "tUe fooj.k", 12);
		drawShape.drawRoundedRectangle(20, pageHeight - 210, 150, 250);
		drawShape.drawRowAndColoum(20, pageHeight - 210, 150, 250, 4);
		String[] labels = constantHindi.birthDetailLabel;
		String[] values = { desktopHoro.getName(), desktopHoro.getName(), desktopHoro.getName(), desktopHoro.getName(),
				desktopHoro.getName() };
		printLabel(drawShape, 25, pageHeight - 80, labels);
		// printValue(drawShape, 150, pageHeight - 80, values);
	}

	void addAvkahadaChakar(float pageHeight, float pageWidth) {
		try {

			/*
			 * drawText(contentStream, "Panchang", 20, pageHeight - 230);
			 * drawRectWithSolid(contentStream, 20, pageHeight - 510, 270, 250, 8); String[]
			 * panchangLabels = { "Paksh", "Tithi", "Nakshatra", "Hindu Day", "English Day",
			 * "Yoga", "Karan", "Sun Rise", "Sun Set" }; printLabel(contentStream, 25,
			 * pageHeight - 260, panchangLabels); printValue(contentStream, 150, pageHeight
			 * - 260, getPanchangData()); drawText(contentStream, "Avakahada Chakar", 290,
			 * pageHeight - 50); drawRectWithSolid(contentStream, 290, pageHeight - 660,
			 * 600, 250, 19); String[] AvakahadaLabels = { "Paya", "Varna", "Yoni", "Gana",
			 * "Vashya", "Nadi", "Dasha Bhogya", "Lagna", "Lagna Swami", "Rashi",
			 * "Rashi Swami", "Nakshtra-Pada", "Nakshtra Swami", "Julian Day", "Sun Sign",
			 * "Sun Sign", "Ayanash", "Ayanash Name", "Ayan Degree", "Samptik kaal" };
			 * printLabel(contentStream, 295, pageHeight - 80, AvakahadaLabels);
			 * printValue(contentStream, 420, pageHeight - 80, getAvakahadaDetail());
			 * contentStream.close();
			 */
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	void addChart() {
		try {
			PDPage page = new PDPage(PDRectangle.A4);
			document.addPage(page);
			contentStream = new PDPageContentStream(document, page);
			contentStream.setLineWidth(1);
			contentStream.setStrokingColor(Color.GRAY);
			contentStream.setNonStrokingColor(Color.BLACK);
			PDRectangle mediaBox = page.getMediaBox();
			float pageWidth = mediaBox.getWidth();
			float pageHeight = mediaBox.getHeight();
			// addPageHeading(contentStream, pageHeight, pageWidth);
			drawText(contentStream, "Lagna Chart", 20, pageHeight - 50);
			drawKundli(contentStream, pageHeight, pageWidth, 20f, pageHeight - 230f);
			float[] x = { 20f + 80, 20f + 38, 20f + 26, 20f + 70, 20f + 26, 20f + 38, 20f + 80, 20f + 124, 20f + 136,
					20f + 95, 20f + 136, 20f + 124 };
			float[] y = { pageHeight - 230f + 90, pageHeight - 230f + 132, pageHeight - 230f + 122,
					pageHeight - 230f + 80, pageHeight - 230f + 40, pageHeight - 230f + 30, pageHeight - 230f + 70,
					pageHeight - 230f + 30, pageHeight - 230f + 40, pageHeight - 230f + 80, pageHeight - 230f + 122,
					pageHeight - 230f + 132 };
			drawRashiInBhav(contentStream, x, y, 10);
			printPlanetsInHouse(20f, pageHeight - 230f + 152);
			drawText(contentStream, "Moon Chart", 20, pageHeight - 250f);
			drawKundli(contentStream, pageHeight, pageWidth, 20f, pageHeight - 430f);
			float[] x1 = { 20f + 80, 20f + 38, 20f + 26, 20f + 70, 20f + 26, 20f + 38, 20f + 80, 20f + 124, 20f + 136,
					20f + 95, 20f + 136, 20f + 124 };
			float[] y1 = { pageHeight - 430f + 90, pageHeight - 430f + 132, pageHeight - 430f + 122,
					pageHeight - 430f + 80, pageHeight - 430f + 40, pageHeight - 430f + 30, pageHeight - 430f + 70,
					pageHeight - 430f + 30, pageHeight - 430f + 40, pageHeight - 430f + 80, pageHeight - 430f + 122,
					pageHeight - 430f + 132 };
			drawRashiInBhav(contentStream, x1, y1, 10);

			drawText(contentStream, "Navmansh Chart", 20, pageHeight - 450f);
			drawKundli(contentStream, pageHeight, pageWidth, 20f, pageHeight - 630f);
			float[] x2 = { 20f + 80, 20f + 38, 20f + 26, 20f + 70, 20f + 26, 20f + 38, 20f + 80, 20f + 124, 20f + 136,
					20f + 95, 20f + 136, 20f + 124 };
			float[] y2 = { pageHeight - 630f + 90, pageHeight - 630f + 132, pageHeight - 630f + 122,
					pageHeight - 630f + 80, pageHeight - 630f + 40, pageHeight - 630f + 30, pageHeight - 630f + 70,
					pageHeight - 630f + 30, pageHeight - 630f + 40, pageHeight - 630f + 80, pageHeight - 630f + 122,
					pageHeight - 630f + 132 };
			drawRashiInBhav(contentStream, x2, y2, 10);
			drawText(contentStream, "Planetray Position", 210, pageHeight - 50);
			drawPlanetPositionTable(contentStream, 210, pageHeight - 480, 420, 360);
			drawText(contentStream, "Ashtakvarga Table", 210, pageHeight - 500);
			drawAshtakvargaTable(contentStream, 210, pageHeight - 780, 270, 360);
			contentStream.close();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	void addChalitChart() {
		try {
			PDPage page = new PDPage(PDRectangle.A4);
			document.addPage(page);
			contentStream = new PDPageContentStream(document, page);
			contentStream.setLineWidth(1);
			contentStream.setStrokingColor(Color.GRAY);
			contentStream.setNonStrokingColor(Color.BLACK);
			PDRectangle mediaBox = page.getMediaBox();
			float pageWidth = mediaBox.getWidth();
			float pageHeight = mediaBox.getHeight();
			// addPageHeading(contentStream, pageHeight, pageWidth);
			drawText(contentStream, "Chalit Chart", 20, pageHeight - 50);
			drawKundli(contentStream, pageHeight, pageWidth, 20f, pageHeight - 230f);
			drawText(contentStream, "Chalit Table", 210, pageHeight - 50);
			drawChalitTable(contentStream, 210, pageHeight - 450, 390, 360);
			contentStream.close();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	void printLabel(DrawShape drawShape, float x, float pageHeight, String[] labels) {
		//
		float y = pageHeight;
		for (int i = 0; i < labels.length; i++) {
			try {
				drawShape.drawKrutiDevText(x, y, labels[i], 12);
				y = y - 30;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	void printValue(DrawShape drawShape, float x, float pageHeight, String[] values) {
		// String[] labels = { "Name1", "Name2", "Name3", "Name4", "Name5" };
		float y = pageHeight;
		for (int i = 0; i < values.length; i++) {
			try {
				drawShape.drawText(x/* 150 */, y, values[i], 10);
				y = y - 30;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public void drawRectWithSolid(PDPageContentStream contentStream, float x, float y, float height, float width,
			int rowCount) throws IOException {
		// contentStream.setNonStrokingColor(Color.RED); // Set fill color
		contentStream.setStrokingColor(Color.black);
		contentStream.setNonStrokingColor(Color.WHITE);
		contentStream.addRect(x, y, width, height);
		contentStream.fill();
		contentStream.moveTo(x, y);
		contentStream.lineTo(x, y + height);
		contentStream.lineTo(x + width, y + height);
		contentStream.lineTo(x + width, y);
		contentStream.lineTo(x, y);
		contentStream.closePath();
		contentStream.stroke();

		drawRowAndColoum(contentStream, x, y, height, width, rowCount);
	}

	void drawRowAndColoum(PDPageContentStream contentStream, float x, float y, float height, float width,
			int rowCount) {

		float yAxis = y + 30;
		try {
			contentStream.setNonStrokingColor(Color.black);
			for (int i = 0; i < rowCount; i++) {
				drawLine(contentStream, x, yAxis, x + width, yAxis);
				yAxis += 30;
			}
			drawLine(contentStream, x + 120, y + (rowCount + 1) * 30, x + 120, y);
		} catch (Exception e) {

		}

	}

	public void drawLine(PDPageContentStream contentStream, float x1, float y1, float x2, float y2) throws IOException {
		contentStream.moveTo(x1, y1);
		contentStream.lineTo(x2, y2);
		contentStream.stroke();
	}

	public void drawText(PDPageContentStream contentStream, String text, float x, float y) throws IOException {
		contentStream.setNonStrokingColor(Color.BLACK); // Set fill color
		contentStream.setStrokingColor(Color.BLACK);
		contentStream.beginText();
		PDType0Font font = PDType0Font.load(document, new File("E:\\fonts\\roboto_medium.ttf"));
		contentStream.setFont(font, 12); // Set font and size
		contentStream.newLineAtOffset(x, y); // Set position
		contentStream.showText(text); // Display text
		contentStream.endText();
	}

	public void drawText(PDPageContentStream contentStream, String text, float x, float y, int fontSize)
			throws IOException {
		contentStream.setNonStrokingColor(Color.BLACK); // Set fill color
		contentStream.setStrokingColor(Color.BLACK);
		contentStream.beginText();
		PDType0Font font = PDType0Font.load(document, new File("E:\\fonts\\roboto_medium.ttf"));
		contentStream.setFont(font, fontSize); // Set font and size
		contentStream.newLineAtOffset(x, y); // Set position
		contentStream.showText(text); // Display text
		contentStream.endText();
	}

	void initHoro() {
		desktopHoro = new DesktopHoro();
		Local planetLocal = new Local();
		// planetLocal.loadPropertiesFileNew("", 1);
		try {
			desktopHoro.setName("Amit");
			desktopHoro.setPlace("New Delhi");
			desktopHoro.setTimeZone("5.5");
			desktopHoro.setMaleFemale("M");
			desktopHoro.setSecondOfBirth("5");
			desktopHoro.setMinuteOfBirth("22");
			desktopHoro.setHourOfBirth("9");
			desktopHoro.setDayOfBirth("7");
			desktopHoro.setMonthOfBirth("4");
			desktopHoro.setYearOfBirth("2024");
			desktopHoro.setDegreeOfLattitude("28");
			desktopHoro.setMinuteOfLattitude("38");
			// args1.setSecondOfLattitude("00");
			desktopHoro.setDegreeOfLongitude("77");
			desktopHoro.setMinuteOfLongitude("13");
			// args1.setSecondOfLongitude("00");
			desktopHoro.setEastWest("E");
			desktopHoro.setNorthSouth("N");
			desktopHoro.setLanguageCode("0");
			desktopHoro.setDST("0");
			desktopHoro.setKPHorarySeed(Integer.parseInt("0"));
			desktopHoro.setAyanamsaType(Integer.parseInt("0"));
			desktopHoro.initialize();

			System.out.print(desktopHoro.getAsc());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	String[] getPanchangData() {
		String[] arr = new String[9];
		arr[0] = desktopHoro.getPakshaName();
		arr[1] = desktopHoro.getTithiName();
		arr[2] = desktopHoro.getNakshatraName();
		arr[3] = desktopHoro.getHinduWeekdayName();
		arr[4] = desktopHoro.getHinduWeekdayName();
		arr[5] = desktopHoro.getYoganame();
		arr[6] = desktopHoro.getKaranName();
		arr[7] = desktopHoro.getSunRiseTimeHms();
		arr[8] = desktopHoro.getSunSetTimeHms();

		return arr;
	}

	String[] getAvakahadaDetail() {
		String[] arr = new String[20];
		arr[0] = desktopHoro.getPayaName();
		arr[1] = desktopHoro.getVarnaName();
		arr[2] = desktopHoro.getYoniName();
		arr[3] = desktopHoro.getGanaName();
		arr[4] = desktopHoro.getVasyaName();
		arr[5] = desktopHoro.getNadiName();
		arr[6] = desktopHoro.getBalanceOfDasaString();
		arr[7] = String.valueOf(desktopHoro.getLagna());
		arr[8] = desktopHoro.getLagnaLordName();
		arr[9] = desktopHoro.getRasiName();
		arr[10] = desktopHoro.getRasiLordName();
		arr[11] = desktopHoro.getNakshatraName();
		arr[12] = desktopHoro.getNakshatraLordName();
		arr[13] = desktopHoro.getJulianDayValue();
		arr[14] = desktopHoro.getSunSignName();
		arr[15] = desktopHoro.getSunSignName();
		arr[16] = desktopHoro.getAyanamsaDms();
		arr[17] = desktopHoro.getAyanamsaDms();
		arr[18] = desktopHoro.getAscendentDms();
		arr[19] = desktopHoro.getAscendentDms();
		return arr;
	}

	public void drawKundli(PDPageContentStream contentStream, float ph, float pw, float x, float y) {
		try {

			float rh = 170;
			float rw = 170;
			drawRectWithSolid(contentStream, rh, rw, x, y);
			drawLine(contentStream, x, y, x + rh, y + rh);
			drawLine(contentStream, x, y + rh, x + rh, y);
			drawLine(contentStream, x, y + rh / 2, x + rw / 2, y + rh);
			drawLine(contentStream, x, y + rh / 2, x + rw / 2, y);
			drawLine(contentStream, x + rw / 2, y + rh, x + rw, y + rh / 2);
			drawLine(contentStream, x + rw, y + rh / 2, x + rw / 2, y);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void drawRectWithSolid(PDPageContentStream contentStream, float rh, float rw, float x, float y)
			throws IOException {
		contentStream.setNonStrokingColor(Color.WHITE); // Set fill color
		contentStream.setStrokingColor(Color.BLACK);

		// Draw filled rectangle
		contentStream.addRect(x, y, rh, rw);
		contentStream.fill();
		contentStream.moveTo(x, y);
		contentStream.lineTo(x, y + rh);
		contentStream.lineTo(x + rw, y + rh);
		contentStream.lineTo(x + rw, y);
		contentStream.lineTo(x, y);
		contentStream.closePath();
		contentStream.stroke();
	}

	void drawPlanetPositionTable(PDPageContentStream contentStream, float x, float y, float height, float width)
			throws IOException {
		float k = 0.552284749831f;
		int radius = 6;
		drawTableHeader(contentStream, x, y + 390, 30, width);
		contentStream.setLineWidth(1f);
		contentStream.setStrokingColor(Color.black);
		contentStream.setNonStrokingColor(Color.WHITE);
		// Start from top-left
		contentStream.moveTo(x, y + height - 30);
		// Top line
		contentStream.lineTo(x + width, y + height - 30);
		// Right line
		contentStream.lineTo(x + width, y + radius);
		// Bottom-right corner
		contentStream.curveTo(x + width, y + radius - radius * k, x + width - radius + radius * k, y,
				x + width - radius, y);
		// Bottom line
		contentStream.lineTo(x + radius, y);
		// Bottom-left corner
		contentStream.curveTo(x + radius - radius * k, y, x, y + radius - radius * k, x, y + radius);
		// Left line
		contentStream.lineTo(x, y + height - 30);
		contentStream.closePath();
		contentStream.stroke();
		drawRow(contentStream, x, y, height, width, 13);
		drawLine(contentStream, x + 30, y, x + 30, y + 420);
		drawLine(contentStream, x + 90, y, x + 90, y + 420);
		drawLine(contentStream, x + 140, y, x + 140, y + 420);
		drawLine(contentStream, x + 220, y, x + 220, y + 420);
		populatePlanetPosition(contentStream, x, y, height, width);
	}

	void populatePlanetPosition(PDPageContentStream contentStream, float x, float y, float height, float width)
			throws IOException {
		ArrayList<PlanetDataModel> arrayList = getPlanetData();
		int h = 400;
		for (int i = 0; i < 13; i++) {
			if (i == 0) {
				drawText(contentStream, "ग्रह", x + 5, y + h);
				drawText(contentStream, "ग्रह", x + 35, y + h);
				drawText(contentStream, "ग्रह", x + 95, y + h);
				drawText(contentStream, "ग्रह", x + 145, y + h);
				drawText(contentStream, "ग्रह", x + 225, y + h);
			} else {
				PlanetDataModel planetDataModel = arrayList.get(i);
				drawText(contentStream, planetDataModel.getPlaName(), x + 5, y + h);
				drawText(contentStream, planetDataModel.getSign(), x + 35, y + h);
				drawText(contentStream, planetDataModel.getDegree(), x + 95, y + h);
				drawText(contentStream, planetDataModel.getNaks(), x + 145, y + h);
				drawText(contentStream, planetDataModel.getPlaCharan(), x + 225, y + h);
			}
			h = h - 30;
		}

	}

	ArrayList<PlanetDataModel> getPlanetData() {
		double[] plaDeg = desktopHoro.getPlanetaryDegree();
		String[] planetNames = constantHindi.planetNameWithLagna;
		String[] rashiNames = constantHindi.rasiShortNames;
		String[] nakshNames = constantHindi.naksShortNames;
		ArrayList<PlanetDataModel> arrayList = new ArrayList<PlanetDataModel>();
		PlanetDataModel planetDataModel;
		for (int i = 0; i < 13; i++) {
			planetDataModel = new PlanetDataModel();
			planetDataModel.setPlaName(planetNames[i]);
			planetDataModel.setSign(rashiNames[getRasiNumber(plaDeg[i])]);
			planetDataModel.setNaks(nakshNames[getNakshatraNumber(plaDeg[i])]);
			planetDataModel.setPlaCharan(String.valueOf((getPlntCharan(plaDeg[i]))));
			planetDataModel.setDegree(String.valueOf(plaDeg[i]));
			arrayList.add(planetDataModel);
		}
		return arrayList;
	}

	int getRasiNumber(double deg) {
		return (int) (deg / 30);
	}

	private int getNakshatraNumber(double deg) {
		return (int) (deg * 0.075);
	}

	private int getPlntCharan(double pl) {

		double aa = pl;

		return (int) (4 * fract(aa * 3.0 / 40)) + 1;
	}

	private double fract(double x) {
		double y;
		long i = (long) x;
		y = x - i;
		return y;
	}

	void drawAshtakvargaTable(PDPageContentStream contentStream, float x, float y, float height, float width)
			throws IOException {
		float k = 0.552284749831f;
		int radius = 6;
		drawTableHeader(contentStream, x, y + 240, 30, width);
		contentStream.setLineWidth(1f);
		contentStream.setStrokingColor(Color.black);
		contentStream.setNonStrokingColor(Color.WHITE);
		// Start from top-left
		contentStream.moveTo(x, y + height - 30);
		// Top line
		contentStream.lineTo(x + width, y + height - 30);
		// Right line
		contentStream.lineTo(x + width, y + radius);
		// Bottom-right corner
		contentStream.curveTo(x + width, y + radius - radius * k, x + width - radius + radius * k, y,
				x + width - radius, y);
		// Bottom line
		contentStream.lineTo(x + radius, y);
		// Bottom-left corner
		contentStream.curveTo(x + radius - radius * k, y, x, y + radius - radius * k, x, y + radius);
		// Left line
		contentStream.lineTo(x, y + height - 30);
		contentStream.closePath();
		contentStream.stroke();

		drawRow(contentStream, x, y, height, width, 7);
		drawLine(contentStream, x + width - 25, y, x + width - 25, y + 270);
		drawLine(contentStream, x + width - 25 * 2, y, x + width - 25 * 2, y + 270);
		drawLine(contentStream, x + width - 25 * 3, y, x + width - 25 * 3, y + 270);
		drawLine(contentStream, x + width - 25 * 4, y, x + width - 25 * 4, y + 270);
		drawLine(contentStream, x + width - 25 * 5, y, x + width - 25 * 5, y + 270);
		drawLine(contentStream, x + width - 25 * 6, y, x + width - 25 * 6, y + 270);
		drawLine(contentStream, x + width - 25 * 7, y, x + width - 25 * 7, y + 270);
		drawLine(contentStream, x + width - 25 * 8, y, x + width - 25 * 8, y + 270);
		drawLine(contentStream, x + width - 25 * 9, y, x + width - 25 * 9, y + 270);
		drawLine(contentStream, x + width - 25 * 10, y, x + width - 25 * 10, y + 270);
		drawLine(contentStream, x + width - 25 * 11, y, x + width - 25 * 11, y + 270);
		drawLine(contentStream, x + width - 25 * 12, y, x + width - 25 * 12, y + 270);

	}

	void drawChalitTable(PDPageContentStream contentStream, float x, float y, float height, float width)
			throws IOException {
		float k = 0.552284749831f;
		int radius = 6;
		drawTableHeader(contentStream, x, y + 360, 30, width);
		contentStream.setLineWidth(1f);
		contentStream.setStrokingColor(Color.black);
		contentStream.setNonStrokingColor(Color.WHITE);
		// Start from top-left
		contentStream.moveTo(x, y + height - 30);
		// Top line
		contentStream.lineTo(x + width, y + height - 30);
		// Right line
		contentStream.lineTo(x + width, y + radius);
		// Bottom-right corner
		contentStream.curveTo(x + width, y + radius - radius * k, x + width - radius + radius * k, y,
				x + width - radius, y);
		// Bottom line
		contentStream.lineTo(x + radius, y);
		// Bottom-left corner
		contentStream.curveTo(x + radius - radius * k, y, x, y + radius - radius * k, x, y + radius);
		// Left line
		contentStream.lineTo(x, y + height - 30);
		contentStream.closePath();
		contentStream.stroke();
		drawRow(contentStream, x, y, height, width, 11);
		drawLine(contentStream, x + 30, y, x + 30, y + 390);
		drawLine(contentStream, x + 90, y, x + 90, y + 390);
		drawLine(contentStream, x + 140, y, x + 140, y + 390);
		drawLine(contentStream, x + 220, y, x + 220, y + 390);
	}

	void drawTableHeader(PDPageContentStream contentStream, float x, float y, float height, float width)
			throws IOException {
		float k = 0.552284749831f;
		int radius = 6;
		contentStream.setLineWidth(1f);
		contentStream.setStrokingColor(Color.black);
		contentStream.setNonStrokingColor(Color.LIGHT_GRAY);
		contentStream.moveTo(x + radius, y);
		// Bottom line
		contentStream.lineTo(x + width, y);
		// Bottom-right corner
		contentStream.curveTo(x + width, y, x + width, y, x + width, y);
		// Right line
		contentStream.lineTo(x + width, y + height - radius);
		// Top-right corner
		contentStream.curveTo(x + width, y + height - radius + radius * k, x + width - radius + radius * k, y + height,
				x + width - radius, y + height);
		// Top line
		contentStream.lineTo(x + radius, y + height);
		// Top-left corner
		contentStream.curveTo(x + radius - radius * k, y + height, x, y + height - radius + radius * k, x,
				y + height - radius);
		// Left line
		contentStream.lineTo(x, y);
		// Bottom-left corner
		contentStream.curveTo(x, y, x, y, x, y);
		contentStream.closePath();
		contentStream.fillAndStroke();

	}

	void drawRow(PDPageContentStream contentStream, float x, float y, float height, float width, int rowCount) {

		float yAxis = y + 30;
		try {
			contentStream.setLineWidth(1f);
			contentStream.setNonStrokingColor(Color.black);
			for (int i = 0; i < rowCount; i++) {
				drawLine(contentStream, x, yAxis, x + width, yAxis);
				yAxis += 30;
			}
		} catch (Exception e) {

		}

	}

	@SuppressWarnings({ "deprecation", "unused" })
	private void drawRoundedRectangle(PDPageContentStream contentStream, float x, float y, float width, float height,
			float radius) throws IOException {
		float k = 0.552284749831f; // Control point distance for approximating a quarter circle with a cubic Bezier
									// curve

		contentStream.setLineWidth(1.5f);
		contentStream.setStrokingColor(0, 0, 0);

		// Start point
		contentStream.moveTo(x + radius, y);

		// Bottom line
		contentStream.lineTo(x + width - radius, y);
		// Bottom-right corner
		contentStream.curveTo(x + width - radius + radius * k, y, x + width, y + radius - radius * k, x + width,
				y + radius);

		// Right line
		contentStream.lineTo(x + width, y + height - radius);
		// Top-right corner
		contentStream.curveTo(x + width, y + height - radius + radius * k, x + width - radius + radius * k, y + height,
				x + width - radius, y + height);

		// Top line
		contentStream.lineTo(x + radius, y + height);
		// Top-left corner
		contentStream.curveTo(x + radius - radius * k, y + height, x, y + height - radius + radius * k, x,
				y + height - radius);

		// Left line
		contentStream.lineTo(x, y + radius);
		// Bottom-left corner
		contentStream.curveTo(x, y + radius - radius * k, x + radius - radius * k, y, x + radius, y);

		contentStream.closePath();
		contentStream.stroke();
	}

	private void drawRashiInBhav(PDPageContentStream contentStream, float[] x_axis, float[] y_axis, int lagna)
			throws IOException {
		int lagna1 = lagna;
		for (int i = 0; i < 12; i++) {
			if (lagna1 > 12)
				lagna1 = 1;
			drawText(contentStream, String.valueOf(lagna1), x_axis[i], y_axis[i], 10);
			lagna1++;
		}
	}

	private void printPlanetsInHouse(float x, float y) throws IOException {
		int[] planetArray = desktopHoro.getPositionForShodasvarg(0);
		float[] housePositionsX0 = { x + 10, x + 22, x + 34, x + 46, x + 58, x + 35 };
		float[] housePositionsY0 = { y + 10, y, y + 10, y, y + 10, y - 10, };
		float[] housePositionsX1 = { x + 2, x + 12, x + 2, x + 12, x + 3, x + 22 };
		float[] housePositionsY1 = { y - 5, y - 15, y - 25, y - 35, y - 45, y - 25, };
		float[] housePositionsX2 = { x + 30, x + 50, x + 70, x + 40, x + 60, x + 50 };
		float[] housePositionsY2 = { y, y, y, y + 10, y + 10, y + 20, };
		float[] housePositionsX3 = { x + 30, x + 50, x + 70, x + 40, x + 60, x + 50 };
		float[] housePositionsY3 = { y, y, y, y + 10, y + 10, y + 20, };
		float[] housePositionsX4 = { x + 30, x + 50, x + 70, x + 40, x + 60, x + 50 };
		float[] housePositionsY4 = { y, y, y, y + 10, y + 10, y + 20, };
		float[] housePositionsX5 = { x + 30, x + 50, x + 70, x + 40, x + 60, x + 50 };
		float[] housePositionsY5 = { y, y, y, y + 10, y + 10, y + 20, };
		float[] housePositionsX6 = { x + 30, x + 50, x + 70, x + 40, x + 60, x + 50 };
		float[] housePositionsY6 = { y, y, y, y + 10, y + 10, y + 20, };
		float[] housePositionsX7 = { x + 30, x + 50, x + 70, x + 40, x + 60, x + 50 };
		float[] housePositionsY7 = { y, y, y, y + 10, y + 10, y + 20, };
		float[] housePositionsX8 = { x + 30, x + 50, x + 70, x + 40, x + 60, x + 50 };
		float[] housePositionsY8 = { y, y, y, y + 10, y + 10, y + 20, };
		float[] housePositionsX9 = { x + 30, x + 50, x + 70, x + 40, x + 60, x + 50 };
		float[] housePositionsY9 = { y, y, y, y + 10, y + 10, y + 20, };
		float[] housePositionsX10 = { x + 30, x + 50, x + 70, x + 40, x + 60, x + 50 };
		float[] housePositionsY10 = { y, y, y, y + 10, y + 10, y + 20, };
		float[] housePositionsX11 = { x + 30, x + 50, x + 70, x + 40, x + 60, x + 50 };
		float[] housePositionsY11 = { y, y, y, y + 10, y + 10, y + 20, };

		ArrayList<ArrayList<String>> arrayLists = new ArrayList<>();
		ArrayList<float[]> xArrayLists = new ArrayList<>();
		ArrayList<float[]> yArrayLists = new ArrayList<>();
		xArrayLists.add(housePositionsX0);
		xArrayLists.add(housePositionsX1);
		xArrayLists.add(housePositionsX2);
		xArrayLists.add(housePositionsX3);
		xArrayLists.add(housePositionsX4);
		xArrayLists.add(housePositionsX5);
		xArrayLists.add(housePositionsX6);
		xArrayLists.add(housePositionsX7);
		xArrayLists.add(housePositionsX8);
		xArrayLists.add(housePositionsX9);
		xArrayLists.add(housePositionsX10);
		xArrayLists.add(housePositionsX11);

		yArrayLists.add(housePositionsY0);
		yArrayLists.add(housePositionsY1);
		yArrayLists.add(housePositionsY2);
		yArrayLists.add(housePositionsY3);
		yArrayLists.add(housePositionsY4);
		yArrayLists.add(housePositionsY5);
		yArrayLists.add(housePositionsY6);
		yArrayLists.add(housePositionsY7);
		yArrayLists.add(housePositionsY8);
		yArrayLists.add(housePositionsY9);
		yArrayLists.add(housePositionsY10);
		yArrayLists.add(housePositionsY11);

		for (int i = 0; i < 12; i++) {
			arrayLists.add(new ArrayList<>());
		}
		for (int i = 0; i < planetArray.length; i++) {
			int planetBhav = getBhavOfPlant(planetArray[0], planetArray[i]);
			planetBhav--;
			if (planetBhav >= 12) {
				planetBhav = 0;
			}
			arrayLists.get(planetBhav).add("Mo");
			/*
			 * String spanable = planetsName[i]; if (combustArr != null && combustArr.length
			 * > 0) { if (combustArr[i].equals("1")) { spanable = spanable +
			 * resources.getString(R.string.combust); } } if (i < 12 && retrograteArr !=
			 * null && retrograteArr.length > 0) { if (retrograteArr[i + 1].equals("1")) {
			 * spanable = spanable + resources.getString(R.string.retrograde); } }
			 * arrayLists.get(planetBhav).add(new PlanetData(spanable, paint));
			 */
		}
		ArrayList<String> innerList;
		float[] x_axis;
		float[] y_axis;
		int coordinateIndex;
		for (int i = 0; i < arrayLists.size(); i++) {
			innerList = arrayLists.get(i);
			coordinateIndex = 0;
			if (innerList.size() > 0) {
				x_axis = xArrayLists.get(i);
				y_axis = yArrayLists.get(i);
				for (int j = 0; j < innerList.size(); j++) {
					if (coordinateIndex > 5) {
						coordinateIndex = 0;
					}
					/*
					 * if (combustArr != null && combustArr[j].equals("1")) {
					 * setSpanableString(canvas, innerList.get(j).getPlanetName(),
					 * resources.getString(R.string.combust), x_axis[coordinateIndex],
					 * y_axis[coordinateIndex]); } else {
					 */

					drawText(contentStream, innerList.get(j), x_axis[coordinateIndex], y_axis[coordinateIndex], 8);
					// }
					coordinateIndex++;
				}
			}
		}
	}

	private int getBhavOfPlant(int lagnaRashi, int plntRashi) {
		int bhavNumber;
		bhavNumber = plntRashi - lagnaRashi;
		if (bhavNumber < 0) {
			bhavNumber += 12;
		}
		bhavNumber += 1;
		return 3;
	}
}
