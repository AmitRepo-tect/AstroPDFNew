package com.astroganit.controller;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.astroganit.service.PDFGenerateService;
import com.astroganit.service.PDFGenerateServiceNew;

import jakarta.servlet.http.HttpServletResponse;

@RestController
public class PDFController {

	@Autowired(required = true)
	PDFGenerateService pdfGenerateService;
	@Autowired(required = true)
	PDFGenerateServiceNew pdfGenerateServiceNew;
	/*
	 * @GetMapping({ "/generatepdf" }) void generatePDF() { try {
	 * System.out.print("generatePdf"); pdfGenerateService.generatePDF(); } catch
	 * (IOException e) { }
	 * 
	 * }
	 */

	@GetMapping("/generatepdf")
	public void generatePdf(HttpServletResponse response) throws IOException {
		System.out.print("generatePdf");
		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "attachment; filename=\"drawing.pdf\"");
		try {
			// byte[] baos=padGenerator.generatePdf();
			byte[] baos = pdfGenerateService.generatePDF();
			response.getOutputStream().write(baos);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@GetMapping("/generate")
	public void generatePdfNew(HttpServletResponse response) throws IOException {
		System.out.print("generate");
		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "attachment; filename=\"drawing.pdf\"");
		try {
			// byte[] baos=padGenerator.generatePdf();
			byte[] baos = pdfGenerateServiceNew.generatePDF();
			response.getOutputStream().write(baos);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
