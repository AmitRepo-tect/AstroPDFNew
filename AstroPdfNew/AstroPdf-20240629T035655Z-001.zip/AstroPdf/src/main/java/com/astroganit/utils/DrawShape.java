package com.astroganit.utils;

import java.awt.Color;
import java.io.File;
import java.io.IOException;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType0Font;

import com.ibm.icu.text.Bidi;
import com.ibm.icu.text.Transliterator;

public class DrawShape {
	float pageHeight;
	float pageWidth;
	PDDocument document;
	PDPageContentStream contentStream;

	public void initialize(float pageHeight, float pageWidth, PDDocument document, PDPageContentStream contentStream) {
		this.pageHeight = pageHeight;
		this.pageWidth = pageWidth;
		this.document = document;
		this.contentStream = contentStream;
	}

	public void drawSolidRect(float x, float y, float height, float width, int rowCount) throws IOException {
		contentStream.setStrokingColor(Color.black);
		contentStream.setNonStrokingColor(Color.WHITE);
		contentStream.addRect(x, y, width, height);
		contentStream.fill();
		contentStream.moveTo(x, y);
		contentStream.lineTo(x, y + height);
		contentStream.lineTo(x + width, y + height);
		contentStream.lineTo(x + width, y);
		contentStream.lineTo(x, y);
		contentStream.closePath();
		contentStream.stroke();

		drawRowAndColoum(x, y, height, width, rowCount);
	}

	public void drawRowAndColoum(float x, float y, float height, float width, int rowCount) {

		float yAxis = y + 30;
		try {
			contentStream.setNonStrokingColor(Color.black);
			for (int i = 0; i < rowCount; i++) {
				drawLine(x, yAxis, x + width, yAxis);
				yAxis += 30;
			}
			drawLine(x + 120, y + (rowCount + 1) * 30, x + 120, y);
		} catch (Exception e) {

		}

	}

	public void drawLine(float x1, float y1, float x2, float y2) throws IOException {
		contentStream.moveTo(x1, y1);
		contentStream.lineTo(x2, y2);
		contentStream.stroke();
	}

	public void drawText(float x, float y, String text, int fontSize) throws IOException {

		contentStream.setNonStrokingColor(Color.BLACK); // Set fill color
		contentStream.setStrokingColor(Color.BLACK);
		PDType0Font font = PDType0Font.load(document, new File("src/main/resources/fonts/poppins_medium.ttf"));
		contentStream.beginText();
		contentStream.setFont(font, fontSize); // Set font and size
		contentStream.newLineAtOffset(x, y); // Set position
		contentStream.showText(text); // Display text
		contentStream.endText();

	}

	public void drawKrutiDevText(float x, float y, String text, int fontSize) throws IOException {

		contentStream.setNonStrokingColor(Color.BLACK); // Set fill color
		contentStream.setStrokingColor(Color.BLACK);
		PDType0Font font = PDType0Font.load(document, new File("src/main/resources/fonts/Kruti-Dev-Regular.ttf"));
		contentStream.beginText();
		contentStream.setFont(font, fontSize); // Set font and size
		contentStream.newLineAtOffset(x, y); // Set position
		contentStream.showText(text); // Display text
		contentStream.endText();

	}

	public void drawTopRoundedRectangle(float x, float y, float width, float height) throws IOException {
		float k = 0.552284749831f;
		int radius = 2;
		contentStream.setLineWidth(1f);
		contentStream.setStrokingColor(Color.black);
		contentStream.setNonStrokingColor(Color.WHITE);
		// Start from top-left
		contentStream.moveTo(x, y + height);
		// Top line
		contentStream.lineTo(x + width, y + height);
		// Right line
		contentStream.lineTo(x + width, y + radius);
		// Bottom-right corner
		contentStream.curveTo(x + width, y + radius - radius * k, x + width - radius + radius * k, y,
				x + width - radius, y);
		// Bottom line
		contentStream.lineTo(x + radius, y);
		// Bottom-left corner
		contentStream.curveTo(x + radius - radius * k, y, x, y + radius - radius * k, x, y + radius);
		// Left line
		contentStream.lineTo(x, y + height);
		contentStream.closePath();
		contentStream.stroke();
	}

	public void drawRoundedRectangle(float x, float y, float height, float width) throws IOException {
		float k = 0.552284749831f;
		int radius = 6;
		contentStream.setLineWidth(1f);
		contentStream.setStrokingColor(0, 0, 0);

		// Start point
		contentStream.moveTo(x + radius, y);

		// Bottom line
		contentStream.lineTo(x + width - radius, y);
		// Bottom-right corner
		contentStream.curveTo(x + width - radius + radius * k, y, x + width, y + radius - radius * k, x + width,
				y + radius);

		// Right line
		contentStream.lineTo(x + width, y + height - radius);
		// Top-right corner
		contentStream.curveTo(x + width, y + height - radius + radius * k, x + width - radius + radius * k, y + height,
				x + width - radius, y + height);

		// Top line
		contentStream.lineTo(x + radius, y + height);
		// Top-left corner
		contentStream.curveTo(x + radius - radius * k, y + height, x, y + height - radius + radius * k, x,
				y + height - radius);

		// Left line
		contentStream.lineTo(x, y + radius);
		// Bottom-left corner
		contentStream.curveTo(x, y + radius - radius * k, x + radius - radius * k, y, x + radius, y);

		contentStream.closePath();
		contentStream.stroke();
	}
}
